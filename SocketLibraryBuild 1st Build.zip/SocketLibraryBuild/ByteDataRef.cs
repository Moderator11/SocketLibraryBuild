﻿using System;

namespace ByteDataRef
{
    class BDR
    {
        public static void ByteCut_Raw()//Cut byte array with specific size and save into jagged array(27 bytes cut with 10 -> 10, 10, 7 byte array)
        {

            int cutsize = 10;

            string path = @"C:\Users\soo\Desktop\test.txt";

            if (System.IO.File.Exists(path) == false)
            {
                System.IO.File.WriteAllText(path, "If you can read this, that means byte cut algorithm is fully and properly working. This is test for sure"); //Generating FIles For Test
            }

            byte[] data = System.IO.File.ReadAllBytes(path);

            int cutteddatalength = 0;

            if (data.Length % cutsize == 0)
            {
                cutteddatalength = data.Length / cutsize;
            }
            else
            {
                cutteddatalength = data.Length / cutsize + 1;
            }

            byte[][] cutteddata = new byte[cutteddatalength][];

            /*for (int i = 0; i < data.Length; i++)
            {
                Console.WriteLine("Data in " + i + " : " + data[i]);
            }*/

            Console.WriteLine("Size(File size) : " + data.Length);
            Console.WriteLine("Cut size : " + cutsize);
            Console.WriteLine("CuttedSize(1st Ary Count) : " + cutteddata.Length);
            Console.WriteLine("EndByteSize(Last Ary may have different size) : " + (data.Length - (cutteddata.Length - 1) * cutsize));
            Console.WriteLine("Press any key to cut bytes in to cutted array.\n");
            Console.ReadKey();

            for (int i = 0; i < cutteddata.Length; i++)
            {
                if (i == cutteddata.Length - 1)
                {
                    cutteddata[i] = new byte[data.Length - i * cutsize];
                    for (int j = 0; j < cutteddata[i].Length; j++)
                    {
                        cutteddata[i][j] = data[(i * cutsize) + j];
                    }
                }
                else
                {
                    cutteddata[i] = new byte[cutsize];
                    for (int j = 0; j < cutsize; j++)
                    {
                        cutteddata[i][j] = data[(i * cutsize) + j];
                    }
                }
            }

            Console.WriteLine("Bytes are cutted successfully");
            Console.WriteLine("Press any key to view result\n");
            Console.ReadKey();

            for (int i = 0; i < cutteddata.Length; i++)
            {
                for (int j = 0; j < cutteddata[i].Length; j++)
                {
                    Console.WriteLine("1st Ary '{0}', 2st Ary '{1}' data : {2}", i, j, cutteddata[i][j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("Press any key to delete test file in desktop folder");
            Console.ReadKey();
            System.IO.File.Delete(path);
        }

        public static void ShowCuttedResult(byte[][] data)
        {
            for (int i = 0; i < data.Length; i++)
            {
                for (int j = 0; j < data[i].Length; j++)
                {
                    Console.WriteLine("1st Ary '{0}', 2st Ary '{1}' data : {2}", i, j, data[i][j]);
                }
                Console.WriteLine();
            }
        }

        public static byte[][] CutBytes(byte[] data, int cutsize)
        {
            int cutteddatalength = 0;

            if (data.Length % cutsize == 0)
            {
                cutteddatalength = data.Length / cutsize;
            }
            else
            {
                cutteddatalength = data.Length / cutsize + 1;
            }

            byte[][] cutteddata = new byte[cutteddatalength][];

            for (int i = 0; i < cutteddata.Length; i++)
            {
                if (i == cutteddata.Length - 1)
                {
                    cutteddata[i] = new byte[data.Length - i * cutsize];
                    for (int j = 0; j < cutteddata[i].Length; j++)
                    {
                        cutteddata[i][j] = data[(i * cutsize) + j];
                    }
                }
                else
                {
                    cutteddata[i] = new byte[cutsize];
                    for (int j = 0; j < cutsize; j++)
                    {
                        cutteddata[i][j] = data[(i * cutsize) + j];
                    }
                }
            }

            return cutteddata;
        }

        public static byte[] MergeByte(byte[][] data, int cuttedsize)
        {
            int datalength = 0;

            for (int i = 0; i < data.Length; i++)
            {
                datalength += data[i].Length;
            }

            byte[] MergedData = new byte[datalength];

            for (int i = 0; i < data.Length; i++)
            {
                for (int j = 0; j < data[i].Length; j++)
                {
                    MergedData[cuttedsize * i + j] = data[i][j];
                }
            }

            return MergedData;
        }

        public static byte[] MergeByte2(byte[] a, byte[] b)
        {
            byte[] c = new byte[a.Length + b.Length];

            Array.Copy(a, 0, c, 0, a.Length);
            Array.Copy(b, 0, c, a.Length, b.Length);

            return c;
        }

        public static byte[] GetByteFromFront(byte[] raw, int length)
        {
            byte[] result;
            if (raw.Length >= length)
            {
                result = new byte[length];
                for (int i = 0; i < length; i++)
                {
                    result[i] = raw[i];
                }
                return result;
            }
            else
            {
                return new byte[0];
            }
        }

        public static void SplitByteSaveIntoTextFile(byte[][] cutteddata)
        {
            //Requires folder in path in desktop;
            for (int i = 0; i < cutteddata.Length; i++)
            {
                System.IO.File.WriteAllBytes(string.Format(@"C:\Users\soo\Desktop\cutted\{0}.txt", i), cutteddata[i]);
            }
        }

        public static void ShowByteList(byte[] data)
        {
            for (int i = 0; i < data.Length; i++)
            {
                Console.WriteLine(data[i]);
            }
        }

        public static string ByteToHex(byte[] data)
        {
            return BitConverter.ToString(data);
        }
    }
}