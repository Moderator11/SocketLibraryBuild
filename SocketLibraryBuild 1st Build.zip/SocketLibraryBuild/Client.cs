﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using ByteDataRef;
using System.Text;

namespace SocketLibraryBuild
{
    class Client
    {
        private Boolean g_Connected;
        private Socket m_ClientSocket = null;
        private AsyncCallback m_fnReceiveHandler;
        private AsyncCallback m_fnSendHandler;

        public event EventHandler<SocketEventArgs> OnConnectedToServer;
        public event EventHandler<SocketEventArgs> OnDataRecieved;
        public event EventHandler<SocketEventArgs> OnDataSent;
        public event EventHandler<SocketEventArgs> DebugEvent;

        private int bytePerSend = 4096;
        private string pieDataToken = "#V&F2$Q8";
        private char tokenSeparator = '`';
        public List<byte[]> pieData = new List<byte[]>();
        byte[][] data_to_send;
        private int dataCapacity = 4088;
        private int currentIndex = 0;

        public Client()
        {
            m_fnReceiveHandler = new AsyncCallback(handleDataReceive);
            m_fnSendHandler = new AsyncCallback(handleDataSend);
        }

        public Boolean Connected
        {
            get
            {
                return g_Connected;
            }
        }

        public void ConnectToServer(String hostName, UInt16 hostPort)
        {
            m_ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            Boolean isConnected = false;
            try
            {
                m_ClientSocket.Connect(hostName, hostPort);
                isConnected = true;
            }
            catch
            {
                isConnected = false;
            }
            g_Connected = isConnected;

            if (isConnected)
            {
                AsyncObject ao = new AsyncObject(bytePerSend);//받을 수 있는 데이타 크기
                ao.WorkingSocket = m_ClientSocket;
                m_ClientSocket.BeginReceive(ao.Buffer, 0, ao.Buffer.Length, SocketFlags.None, m_fnReceiveHandler, ao);
                DebugEvent(this, new SocketEventArgs("@DEBUG:Connected to " + m_ClientSocket.RemoteEndPoint, null, null));

            }
            else
            {
                DebugEvent(this, new SocketEventArgs("@DEBUG:Failed to Connect to " + m_ClientSocket.RemoteEndPoint, null, null));
            }
        }

        public void StopClient()
        {
            DebugEvent(this, new SocketEventArgs("@DEBUG:Closing client", null, null));
            m_ClientSocket.Close();
        }

        public void SendData(byte[] data)
        {
            dataCapacity = bytePerSend - pieDataToken.Length;
            if (data.Length <= dataCapacity) //data.Length <= 4096 - 8 = 4088
            {
                AsyncObject ao = new AsyncObject(1);
                ao.Buffer = data;
                ao.WorkingSocket = m_ClientSocket;
                try
                {
                    m_ClientSocket.BeginSend(ao.Buffer, 0, ao.Buffer.Length, SocketFlags.None, m_fnSendHandler, ao);
                }
                catch (Exception exc)
                {
                    DebugEvent(this, new SocketEventArgs("@DEBUG:Failed send data, " + exc.Message, null, null));
                }
            }
            else//data.Length > 4088
            {
                data_to_send = BDR.CutBytes(data, dataCapacity);
                SendPieData();
            }
        }

        private void SendPieData()
        {
            if (currentIndex < data_to_send.Length)
            {
                AsyncObject ao = new AsyncObject(data_to_send[currentIndex].Length);
                byte[] token = Encoding.ASCII.GetBytes(pieDataToken);
                byte[] piedata = BDR.MergeByte2(token, data_to_send[currentIndex]);
                ao.Buffer = piedata;
                ao.WorkingSocket = m_ClientSocket;
                try
                {
                    m_ClientSocket.BeginSend(ao.Buffer, 0, ao.Buffer.Length, SocketFlags.None, m_fnSendHandler, ao);
                }
                catch (Exception exc)
                {
                    DebugEvent(this, new SocketEventArgs("@DEBUG:Failed to send piedata[" + currentIndex + "], " + exc.Message, null, null));
                }
            }
            else
            {
                SendData(Encoding.ASCII.GetBytes(pieDataToken + Tokenize("End")));
                currentIndex = 0;
                Array.Clear(data_to_send, 0, data_to_send.Length);
            }
        }

        static string GetIP()
        {
            string strHostName = "";
            strHostName = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            return addr[addr.Length - 1].ToString();
        }

        private void handleDataReceive(IAsyncResult ar)
        {
            AsyncObject ao = (AsyncObject)ar.AsyncState;
            Int32 receivedBytes;

            try
            {
                receivedBytes = ao.WorkingSocket.EndReceive(ar);
            }
            catch(Exception exc)
            {
                DebugEvent(this, new SocketEventArgs("@DEBUG:Failed to receive data, " + exc.Message, null, null));
                return;
            }

            if (receivedBytes > 0)
            {
                Byte[] data = new Byte[receivedBytes];
                Array.Copy(ao.Buffer, data, receivedBytes);

                if (GetTokenFromData(data) == pieDataToken)//if piedata
                {
                    string[] tokens = Encoding.ASCII.GetString(data).Split(tokenSeparator);
                    string token2 = "";
                    if (tokens.Length >= 2)
                    {
                        token2 = tokens[1];
                    }

                    if (token2 == "Next")
                    {
                        currentIndex++;
                        SendPieData();
                    }
                    else if (token2 == "End")
                    {
                        byte[] fullpieData = BDR.MergeByte(pieData.ToArray(), dataCapacity);
                        DebugEvent(this, new SocketEventArgs("@DEBUG:piedata received from " + ao.WorkingSocket.RemoteEndPoint + ", Length=" + fullpieData.Length, null, null));
                        OnDataRecieved(this, new SocketEventArgs(ao.WorkingSocket.RemoteEndPoint.ToString(), fullpieData, null));
                        pieData.Clear();
                        pieData = new List<byte[]>();
                    }
                    else
                    {
                        byte[] dataonly = new byte[data.Length - pieDataToken.Length];
                        Array.ConstrainedCopy(data, pieDataToken.Length, dataonly, 0, dataonly.Length);
                        pieData.Add(dataonly);
                        SendData(Encoding.ASCII.GetBytes(pieDataToken + Tokenize("Next")));
                    }
                }
                else
                {
                    DebugEvent(this, new SocketEventArgs("@DEBUG:data received from " + ao.WorkingSocket.RemoteEndPoint + ", Length=" + data.Length, null, null));
                    OnDataRecieved(this, new SocketEventArgs(ao.WorkingSocket.RemoteEndPoint.ToString(), data, null));
                }
            }

            try
            {
                ao.WorkingSocket.BeginReceive(ao.Buffer, 0, ao.Buffer.Length, SocketFlags.None, m_fnReceiveHandler, ao);
            }
            catch (Exception exc)
            {
                DebugEvent(this, new SocketEventArgs("@DEBUG:Failed begin async receive" + exc.Message, null, null));
                return;
            }
        }


        private string Tokenize(string str)
        {
            return tokenSeparator + str + tokenSeparator;
        }

        private string GetTokenFromData(byte[] data)
        {
            if (data.Length >= pieDataToken.Length)
            {
                byte[] token = new byte[pieDataToken.Length];
                for (int i = 0; i < token.Length; i++)
                {
                    token[i] = data[i];
                }
                string res = Encoding.ASCII.GetString(token);
                return res;
            }
            else
            {
                return null;
            }
        }

        private void handleDataSend(IAsyncResult ar)
        {
            AsyncObject ao = (AsyncObject)ar.AsyncState;
            Int32 sentBytes;

            try
            {
                sentBytes = ao.WorkingSocket.EndSend(ar);
            }
            catch (Exception exc)
            {
                DebugEvent(this, new SocketEventArgs("@DEBUG:Failed send data, " + exc.Message, null, null));
                return;
            }

            if (sentBytes > 0)
            {
                Byte[] data = new Byte[sentBytes];
                Array.Copy(ao.Buffer, data, sentBytes);

                DebugEvent(this, new SocketEventArgs("@DEBUG:data sent to " + ao.WorkingSocket.RemoteEndPoint + ", Length=" + data.Length, null, null));
            }
        }
    }
}
