﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace SocketLibraryBuild
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("1:Start as server\n\n2:Start as client\n\n_>");
            switch (Console.ReadLine())
            {
                case "1":
                    Console.Title += "-server";
                    Console.Clear();
                    Server_();
                    break;
                case "2":
                    Console.Title += "-client";
                    Console.Clear();
                    Client_();
                    break;
            }
        }

        static void Server_()
        {
            Server s = new Server();
            s.OnDataRecieved += new EventHandler<SocketEventArgs>(Datarecieved);
            s.DebugEvent += new EventHandler<SocketEventArgs>(Debug);
            while (true)
            {
                Console.Write("_>");
                switch (Console.ReadLine())
                {
                    case "test":
                        s.StartServer(s.GetIP(), 1234);
                        break;
                    case "start":
                        Console.Write("Port ? ");
                        s.StartServer(s.GetIP(), UInt16.Parse(Console.ReadLine()));
                        break;
                    case "stop":
                        s.StopServer();
                        break;
                    case "send":
                        Console.Write("data=");
                        s.SendData(Encoding.ASCII.GetBytes(Console.ReadLine()));
                        break;
                    case "send file":
                        Console.Write("path=");
                        string path = Console.ReadLine();
                        string name = path.Split(new string[] { @"\" }, StringSplitOptions.None)[path.Split(new string[] { @"\" }, StringSplitOptions.None).Length - 1];
                        try { byte[] data = System.IO.File.ReadAllBytes(path); s.SendData(ByteDataRef.BDR.MergeByte2(Encoding.ASCII.GetBytes("file@" + name + "@"), data)); }
                        catch { Console.WriteLine("Wrong path"); }
                        break;
                    case "check data loss":
                        Console.WriteLine("Preparing data to test data loss...\n");
                        byte[] bigdata = new byte[600000];
                        Random r = new Random(0);
                        for (int i = 0; i < bigdata.Length; i++)
                        {
                            bigdata[i] = (byte)r.Next(0, 100);
                        }
                        Console.WriteLine("Data prepared, Press any key to continue...");
                        Console.ReadKey();
                        s.SendData(bigdata);
                        break;
                    case "clear":
                        Console.Clear();
                        break;
                    case "exit":
                        return;
                    case "help":
                        Console.WriteLine("start\nsend\nstop\nclear\nexit\nhelp\ncheck data loss\nsend file");
                        break;
                    default:
                        Console.WriteLine("No command, type 'help' to show list commands");
                        break;
                }
            }
        }

        static void Client_()
        {
            Client c = new Client();
            c.OnDataRecieved += new EventHandler<SocketEventArgs>(Datarecieved);
            c.DebugEvent += new EventHandler<SocketEventArgs>(Debug);
            while (true)
            {
                Console.Write("_>");
                switch (Console.ReadLine())
                {
                    case "test":
                        c.ConnectToServer("192.168.0.6", 1234);
                        break;
                    case "connect":
                        Console.Write("Ip ? ");
                        string ip = Console.ReadLine();
                        Console.Write("Port ? ");
                        ushort port = ushort.Parse(Console.ReadLine());
                        c.ConnectToServer(ip, port);
                        break;
                    case "send":
                        Console.Write("data=");
                        c.SendData(Encoding.ASCII.GetBytes(Console.ReadLine()));
                        break;
                    case "send file":
                        Console.Write("path=");
                        string path = Console.ReadLine();
                        string name = path.Split(new string[] { @"\" }, StringSplitOptions.None)[path.Split(new string[] { @"\" }, StringSplitOptions.None).Length - 1];
                        try { byte[] data = System.IO.File.ReadAllBytes(path); c.SendData(ByteDataRef.BDR.MergeByte2(Encoding.ASCII.GetBytes("file@" + name + "@"), data)); }
                        catch { Console.WriteLine("Wrong path"); }
                        break;
                    case "check data loss":
                        Console.WriteLine("Preparing data to test data loss...\n");
                        byte[] bigdata = new byte[600000];
                        Random r = new Random(0);
                        for (int i = 0; i < bigdata.Length; i++)
                        {
                            bigdata[i] = (byte)r.Next(0, 100);
                        }
                        Console.WriteLine("Data prepared, Press any key to continue...");
                        Console.ReadKey();
                        c.SendData(bigdata);
                        break;
                    case "stop":
                        c.StopClient();
                        break;
                    case "clear":
                        Console.Clear();
                        break;
                    case "exit":
                        return;
                    case "help":
                        Console.WriteLine("connect\nsend\nstop\nclear\nexit\nhelp\ncheck data loss\nsend file");
                        break;
                    default:
                        Console.WriteLine("No command, type 'help' to show list commands");
                        break;
                }
            }
        }

        static void Datarecieved(object sender, SocketEventArgs e)
        {
            byte[] data = e.data;
            string[] tokens = Encoding.ASCII.GetString(ByteDataRef.BDR.GetByteFromFront(data, 500)).Split('@');//500 -> Max total token length
            if (tokens[0] == "file")
            {
                try
                {
                    Debug(null, new SocketEventArgs("@DEBUG:File imcoming=" + tokens[1], null, null));
                    byte[] filedata = new byte[data.Length - tokens[0].Length - tokens[1].Length - 2];//-2 means two Separator '@' which is same as (tokens.Length - 1)
                    Array.ConstrainedCopy(data, tokens[0].Length + tokens[1].Length + 2, filedata, 0, filedata.Length);//+2 also means '@'
                    System.IO.File.WriteAllBytes(Environment.CurrentDirectory + @"\" + tokens[1], filedata);
                    Debug(null, new SocketEventArgs("@DEBUGFile successfully saved", null, null));
                }
                catch (Exception exc)
                {
                    Debug(null, new SocketEventArgs("File save aborted, " + exc.Message, null, null));
                }
            }
            else
            {
                Console.ForegroundColor = (ConsoleColor)2;
                Console.WriteLine(string.Format("Receiving data from {0}, Length = {1}", e.msg, data.Length));
                Console.ForegroundColor = (ConsoleColor)3;
                Console.WriteLine("HEX Data = " + BitConverter.ToString(data).Replace("-", " "));
                Console.ForegroundColor = (ConsoleColor)6;
                Console.WriteLine("ASCII Converted = " + Encoding.ASCII.GetString(data));
                Console.ForegroundColor = (ConsoleColor)7;
                Console.Write("_>");
            }
}

        static void Debug(object sender, SocketEventArgs e)
        {
            Console.ForegroundColor = (ConsoleColor)8;
            Console.WriteLine(Environment.NewLine + e.msg);
            Console.ForegroundColor = (ConsoleColor)7;
        }
    }
}
