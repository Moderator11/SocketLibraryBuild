﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;

namespace SocketLibraryBuild
{
    public class AsyncObject
    {
        public Byte[] Buffer;
        public Socket WorkingSocket;
        public AsyncObject(Int32 bufferSize)
        {
            this.Buffer = new Byte[bufferSize];
        }
    }
}
