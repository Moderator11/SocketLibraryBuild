﻿using System;
using System.Collections.Generic;

namespace SocketLibraryBuild
{
    public class SocketEventArgs : EventArgs
    {
        public string msg { get; set; }
        public byte[] data { get; set; }
        public List<Object> odata { get; set; }
        public SocketEventArgs(string _msg = null, byte[] _data = null, List<Object> _odata = null)
        {
            msg = _msg;
            data = _data;
            odata = _odata;
        }
    }
}