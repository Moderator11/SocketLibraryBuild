﻿using System;
using System.Linq;

namespace BaseConverter
{
    class BaseConverter
    {
        public static void Example()
        {
            int number = int.Parse(Console.ReadLine());
            for (int i = 2; i <= 36; i++)//number matching alphabet has no table index over 36(alphabet number : 27)
            {   
                Console.WriteLine(number + " (10) 에 대한 " + i + " 진수 : " + DecimalToSomething(number, i) + " (" + i + ")");

            }

            Console.WriteLine("\nReConverting...\n");

            for (int i = 2; i <= 36; i++)//number matching alphabet has no table index over 36(alphabet number : 27)
            {
                Console.WriteLine(DecimalToSomething(number, i) + " (" + i + ")" + " 에 대한 10 진수 : " + SomethingToDecimal(DecimalToSomething(number, i), i) + " (10)");
            }
        }

        public static string TenToOne(int num)
        {
            string one = "";

            for (int i = 0; i < num; i++)
            {
                one += '1';
            }

            return one;
        }

        public static string DecimalToSomething(int num, int to)
        {
            string output = "";

            #region toisnot1or0

            if (num >= to)
            {
                while (num >= to)
                {
                    if (num % to == 0)
                    {
                        output += '0';
                        num /= to;
                    }
                    else
                    {
                        if (num % to >= 10)
                        {
                            output += MatchNumberToAlphabet(num % to);
                            num /= to;
                        }
                        else
                        {
                            output += (num % to).ToString();
                            num /= to;
                        }
                    }
                    //Console.WriteLine(string.Format("num={0}, output={1}", num, output));
                }
                if (num < 10)
                {
                    output += num;
                }
                else
                {
                    output += MatchNumberToAlphabet(num);
                }
            }
            else
            {
                if (num == 0)
                {
                    output += '0';
                }
                else if (num < 10)
                {
                    output += num.ToString();
                }
                else
                {
                    output += MatchNumberToAlphabet(num);
                }
            }

            #endregion

            #region stringflip

            string tmp = "";
            for (int i = 0; i < output.Length; i++)
            {
                tmp += output[output.Length - 1 - i];
            }
            output = tmp;

            #endregion

            //Console.WriteLine(":Final: = " + output);
            return output;
        }

        public static int SomethingToDecimal(string num, int what)
        {
            int output = 0;

            for (int i = 0; i < num.Length; i++)
            {
                if (isNumber(num[i]) == true)
                {
                    output += int.Parse(num[i].ToString()) * Pow(what, num.Length - 1 - i);
                }
                else
                {
                    output += MatchAlphabetToNumber(num[i]) * Pow(what, num.Length - 1 - i);
                }
            }

            return output;
        }

        public static int Pow(int a, int b)
        {
            int n = a;
            if (b > 0)
            {
                for (int i = 0; i < b - 1; i++)
                {
                    a *= n;
                }
                return a;
            }
            else if (b == 0)
            {
                return 1;
            }
            else
            {
                return 0;//Because int
            }
        }

        private static bool isNumber(char c)
        {
            if (c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static char MatchNumberToAlphabet(int num)
        {
            string alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";//Aphabet O(o) is confusing with number 0(zero)
            if (num >= 10 && num - 10 < alphabets.Length)
            {
                return alphabets[num - 10];
            }
            else
            {
                return '-';//or return ('num') to show what the remainder is
            }
        }

        static int MatchAlphabetToNumber(char chr)
        {
            string alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";//Aphabet O(o) is confusing with number 0(zero)
            for (int i = 0; i < alphabets.Length; i++)
            {
                if (alphabets[i] == chr)
                {
                    return i + 10;
                }
            }
            return -1;//NotFound
        }

        public static void TenToBinary()
        {
            int num = int.Parse(Console.ReadLine());

            string binarydata = "";
            if (num == 0)
            {
                Console.WriteLine("0");
            }
            else
            {
                while (num > 0)
                {
                    if (num % 2 == 0)
                    {
                        num /= 2;
                        binarydata += "0";
                    }
                    else if (num % 2 == 1)
                    {
                        num /= 2;
                        binarydata += "1";
                    }
                }

                string revstr = "";

                for (int i = 0; i < binarydata.Length; i++)
                {
                    revstr += binarydata[binarydata.Length - 1 - i];
                }
                Console.WriteLine(revstr);
            }
        }
    }
}