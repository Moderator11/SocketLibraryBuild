Connection
File Send
big bytes send(cut and send end mend)


Require
BytePerSend variable access form userinferface
Memory optimize


2020-12-16 8:17 pm